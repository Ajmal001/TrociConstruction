largeCSV2mySQL
==============

a php script to import very large csv file to Mysql database in one minute

This script uploads a csv with 2 Million rows in 60 seconds.


Instructions :

1. Keep this php file and Your csv file in one folder 
2. Create a table in your mysql database to which you want to import 
3. Open the php file from you you localhost server 
4. Enter all the fields 
5. click on upload button 

The fastest way to import a CSV file is to use Mysql LOAD DATA command.

For More info check my blog post http://medium.com/@sanathkumar/e6d639b790ab

